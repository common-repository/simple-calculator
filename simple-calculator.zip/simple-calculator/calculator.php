<?php
/**
 * @package scalculator
 * @version 1.6
 */
/*
Plugin Name: scalculator
Plugin URI: http://www.devzoneindia.com
Description: scalculator offical plugin for Calculation functionality
Author: Ronak Dave
Version: 1.0
Author URI: http://www.devzoneindia.com/
*/
add_action('admin_menu', 'scalculator_plugin_menu');

function scalculator_plugin_menu() {
	add_options_page('scalculator Plugin Setup', 'scalculator', 'manage_options', 'scalculator', 'scalculator_plugin_options');
}

function scalculator_plugin_options() {
?>
<script type="application/javascript">
http = getHTTPObject();
 
function getHTTPObject(){
  var xmlhttp;
 
  /*@cc_on
 
  @if (@_jscript_version >= 5)
    try {
      xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }catch(e){
      try{
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }catch(E){
      xmlhttp = false;
    }
  }
  @else
    xmlhttp = false;
  @end @*/
 
  if(!xmlhttp && typeof XMLHttpRequest != 'undefined'){
    try {
      xmlhttp = new XMLHttpRequest();
    }catch(e){
      xmlhttp = false;
    }
  }
 
  return xmlhttp;
}
 
function doMath(){
  var url = "<?php echo get_bloginfo('url') ?>/wp-content/plugins/simple-calculator/calc.php?op=" + document.getElementById('op').value;
  url += "&num1=" + document.getElementById('num1').value;
  url += "&num2=" + document.getElementById('num2').value;
 
  http.open("GET", url, true);
  http.onreadystatechange = handleHttpResponse;
 
  http.send(null);
}
 
function handleHttpResponse(){
  if(http.readyState == 4){
    document.getElementById('answer').innerHTML = http.responseText;
  }
}
</script>
<h2>Welcome to Simple Calculator</h2>
<br />
Input Value 1 : <input type="text" id="num1" size="6">
<select id="op">
<option value="add">+</option>
<option value="subtract">-</option>
<option selected="selected" value="multiply">*</option>
<option value="divide">/</option>
</select>
Input Value 2 : <input type="text" id="num2" size="6">
<input type="button" value=" = " onClick="doMath();"><div style="display: inline; font-size: 16px"> The Answer is <div id="answer" style="display: inline; font-size: 16px"></div> </div>
<br />
<strong>This Calculator is build for Admin use Only. Thank you for Using Our Plugin.</strong>
<?php
}
?>